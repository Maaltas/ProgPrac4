public interface Cloneable {
    public Object clone() throws CloneNotSupportedException;
}
