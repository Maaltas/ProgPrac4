public class ArbreException extends Exception {
    private long serialVersionUID;
    public ArbreException(String errorMessage) {super(errorMessage);}


}
